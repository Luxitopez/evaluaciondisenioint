(function(window, undefined) {

  var jimLinks = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_1" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Text_7" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_36" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_39" : [
        "a13847c8-0992-4176-8019-833e962a92a4"
      ],
      "Paragraph_43" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ],
      "Paragraph_1" : [
        "93bcf8e9-f00b-4ccb-b3c8-6d45d1502fe4"
      ]
    },
    "1944d443-e6dd-47d0-b943-2560e7d4c9d8" : {
      "Image_1" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Text_7" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_12" : [
        "a13847c8-0992-4176-8019-833e962a92a4"
      ],
      "Paragraph_36" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Rectangle_1" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ],
      "Paragraph_1" : [
        "93bcf8e9-f00b-4ccb-b3c8-6d45d1502fe4"
      ]
    },
    "93bcf8e9-f00b-4ccb-b3c8-6d45d1502fe4" : {
      "Rectangle_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_7" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Text_2" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Image_11" : [
        "43b7f457-289b-4513-928d-cdb07c07ccce"
      ],
      "Text_12" : [
        "43b7f457-289b-4513-928d-cdb07c07ccce"
      ],
      "Paragraph_13" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_19" : [
        "93bcf8e9-f00b-4ccb-b3c8-6d45d1502fe4"
      ],
      "Paragraph_39" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ],
      "Paragraph_20" : [
        "a13847c8-0992-4176-8019-833e962a92a4"
      ]
    },
    "a13847c8-0992-4176-8019-833e962a92a4" : {
      "Image_1" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Rectangle_1" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ],
      "Rectangle_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_7" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_36" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_39" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ],
      "Paragraph_1" : [
        "93bcf8e9-f00b-4ccb-b3c8-6d45d1502fe4"
      ]
    },
    "d916a7ee-1416-4434-86cd-e5d3a7c8a810" : {
      "Image_25" : [
        "43b7f457-289b-4513-928d-cdb07c07ccce"
      ],
      "Image_26" : [
        "43b7f457-289b-4513-928d-cdb07c07ccce"
      ],
      "Image_27" : [
        "43b7f457-289b-4513-928d-cdb07c07ccce"
      ],
      "Button_1" : [
        "a13847c8-0992-4176-8019-833e962a92a4"
      ],
      "Button_2" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ]
    },
    "43b7f457-289b-4513-928d-cdb07c07ccce" : {
      "Rectangle_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_8" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Text_1" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_17" : [
        "d916a7ee-1416-4434-86cd-e5d3a7c8a810"
      ],
      "Paragraph_23" : [
        "93bcf8e9-f00b-4ccb-b3c8-6d45d1502fe4"
      ],
      "Paragraph_39" : [
        "1944d443-e6dd-47d0-b943-2560e7d4c9d8"
      ],
      "Paragraph_24" : [
        "a13847c8-0992-4176-8019-833e962a92a4"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);